import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CompanyeditPage } from './companyedit';

@NgModule({
  declarations: [
    CompanyeditPage,
  ],
  imports: [
    IonicPageModule.forChild(CompanyeditPage),
  ],
})
export class CompanyeditPageModule {}

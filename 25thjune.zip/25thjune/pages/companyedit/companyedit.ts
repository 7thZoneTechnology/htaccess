import { Component } from '@angular/core';

import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {  OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
/**
 * Generated class for the CompanyeditPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-companyedit',
  templateUrl: 'companyedit.html',
})
export class CompanyeditPage implements OnInit {
  user: FormGroup;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }
  public buttonClicked: boolean = false; //Whatever you want to initialise it as

  public onButtonClick() {

      this.buttonClicked = !this.buttonClicked;
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad CompanyaddPage');
  }
  ngOnInit() {

    this.user = new FormGroup({
    companyname: new FormControl('', [Validators.required, Validators.minLength(4)]),
    designation: new FormControl('', [Validators.required, Validators.minLength(4)]),
    name: new FormControl('', [Validators.required, Validators.minLength(4)]),
    shortname: new FormControl('', [Validators.required, Validators.minLength(4)]),
    website: new FormControl('', [Validators.required, Validators.minLength(4)]),
    loginname: new FormControl('', [Validators.required, Validators.minLength(4)]),
    adminname: new FormControl('', [Validators.required, Validators.minLength(4)]),
    email: new FormControl('', [Validators.required,Validators.email])
    
    });
    
    }
}

import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CompanyaddPage } from './companyadd';

@NgModule({
  declarations: [
    CompanyaddPage,
  ],
  imports: [
    IonicPageModule.forChild(CompanyaddPage),
  ],
})
export class CompanyaddPageModule {}

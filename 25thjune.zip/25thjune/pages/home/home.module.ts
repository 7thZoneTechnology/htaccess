// Angular
import { NgModule } from '@angular/core';

// Ionic
import { IonicPageModule } from 'ionic-angular';

// Pages
import { HomePage } from './home';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
    declarations: [HomePage],
    imports: [HttpClientModule,NgxDatatableModule,IonicPageModule.forChild(HomePage)],
    exports: [HomePage]
})
export class HomePageModule { }



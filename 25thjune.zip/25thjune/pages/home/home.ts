// Angular
import { Component,ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { PopoverController} from 'ionic-angular';
// Ionic
import { NavController, IonicPage } from "ionic-angular";

import { PopoverComponent  } from '../../components/popover/popover';
import { DatatableComponent } from '@swimlane/ngx-datatable';

// Side Menu Component
import { SideMenuDisplayText } from '../../shared/side-menu-content/custom-decorators/side-menu-display-text.decorator';
export interface Config {
	technologies: string;
}

@IonicPage()
@Component({
	selector: 'page-home',
	templateUrl: 'home.html'
})

@SideMenuDisplayText('Home')

export class HomePage {
  
temp = [];
  @ViewChild(DatatableComponent) table:DatatableComponent;
  totalSize:number;
  pageSize:number;
  currentPage:number; // 1 based paging for ng-bootstrap

  limitOptions = [
    {
      key: '5',
      value: 5
    },
    {
      key: '10',
      value: 10
    },
    {
      key: '20',
      value: 20
    }
  ];
   /**
    * @name config
    * @type {any}
    * @public
    * @description     Defines an object allowing the interface properties to be accessed
    */
   public config : Config;




   /**
    * @name columns
    * @type {any}
    * @public
    * @description     Defines an object for storing the column definitions of the datatable
    */
   public columns : any;




   /**
    * @name rows
    * @type {any}
    * @public
    * @description     Defines an object for storing returned data to be displayed in the template
    */
   public rows : any;


	constructor(private navCtrl: NavController,public popoverCtrl: PopoverController, public _HTTP : HttpClient) {


		// Define the columns for the data table
      // (based off the names of the keys in the JSON file)
      this.columns = [
        { prop: 'Company Name' },
        { prop: 'Company AdminName' },
        { prop: 'Company AdminEmail' },
        { prop: 'Country' },
        { prop: 'Contact Number' }
      ];
	 }
	 ionViewDidLoad() : void
	 {
		this._HTTP
		.get<Config>('../../assets/data/techologies.json')
		.subscribe((data) =>
		{
		   this.rows = data.technologies;
		});
  
	 }

	public goToOption(): void {
        this.navCtrl.setRoot('OptionOnePage');
        
	}

	public goToSubOption(): void {
		this.navCtrl.setRoot('SubOptionTwoPage');
	}



	openPopover(myEvent) {
		let popover = this.popoverCtrl.create(PopoverComponent);
		popover.present({
		  ev: myEvent
		});
	  }


      ngOnInit() {
        this.currentPage = 1;
        this.pageSize = 10;
        this.table.limit = 10;
    
        this.updateData();
      }
    
      onPageChanged(pageNum) {
        this.currentPage = pageNum;
        this.table.offset = pageNum - 1;
      }
    
      onSort(event) {
        this.onPageChanged(1);
      }
    
      updateData() {
        let dataLength = 50 + Math.floor(Math.random() * 100);
    
        this.rows = [];
    
        for (var i = 0; i < dataLength; i++) {
          this.rows.push({
            name: 'name ' + (i + 1),
            age: Math.floor(Math.random() * 50)
          });
        }
    
        this.totalSize = this.rows.length;
    
        // clear sorting on new data
        this.table.sorts = [];
    
        // reset current pagination to first page after data refresh
        this.onPageChanged(1);
      }
    
      onPageSizeChanged(event) {
        this.table.limit = event;
        this.onPageChanged(1);
        this.rows = this.rows.slice();
        console.log(event);
      }
      updateFilter(event) {
        const val = event.target.value.toLowerCase();
    
        // filter our data
        const temp = this.temp.filter(function(d) {
          return d.name.toLowerCase().indexOf(val) !== -1 || !val;
        });
    
        // update the rows
        this.rows = temp;
        // Whenever the filter changes, always go back to the first page
        this.table.offset = 0;
      }
      showProfilePage() {
        this.navCtrl.push('CompanyaddPage');
    }  
    showProfileEditPage()
    {
      this.navCtrl.push('CompanyeditPage');

    }
}
 
 

















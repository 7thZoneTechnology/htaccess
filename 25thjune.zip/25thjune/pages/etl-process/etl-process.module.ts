// Angular
import { NgModule } from '@angular/core';

// Ionic
import { IonicPageModule } from 'ionic-angular';

// Pages
import { EtlProcess } from './etl-process';

@NgModule({
    declarations: [EtlProcess],
    imports: [IonicPageModule.forChild(EtlProcess)],
    exports: [EtlProcess]
})



export class EtlProcessModule { }
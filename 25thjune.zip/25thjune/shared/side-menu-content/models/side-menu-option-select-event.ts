// SideMenuOptionSelect constant
export const SideMenuOptionSelect: string = 'sideMenu:optionSelect';

// SideMenuOptionSelectData interface
export interface SideMenuOptionSelectData {
	displayText?: string;
}
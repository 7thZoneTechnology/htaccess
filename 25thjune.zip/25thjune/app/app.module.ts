import { FormsModule } from '@angular/forms';
import { MbscModule } from '@mobiscroll/angular-lite';
// Angular
import { NgModule, ErrorHandler, Injector } from '@angular/core'; // tslint:disable-line
import { BrowserModule } from '@angular/platform-browser';

// Ionic
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';

// Ionic Native
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

// App
import { MyApp } from './app.component';
import { PopoverComponent  } from '../components/popover/popover';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { HttpClientModule } from '@angular/common/http';
import { ContactPage } from '../pages/contact/contact';
import { BillingPage } from '../pages/billing/billing';
import { SettingPage } from '../pages/setting/setting';
import { ConfigPage } from '../pages/config/config';

// Custom components
import { SideMenuContentComponent } from '../shared/side-menu-content/side-menu-content.component';

@NgModule({
  declarations: [MyApp, SideMenuContentComponent,PopoverComponent,ContactPage,BillingPage
  ,SettingPage,ConfigPage],
  imports: [ 
    FormsModule, 
    MbscModule,BrowserModule,HttpClientModule,NgxDatatableModule, IonicModule.forRoot(MyApp)],
  bootstrap: [IonicApp],
  entryComponents: [MyApp,PopoverComponent,ContactPage,BillingPage
    ,SettingPage,ConfigPage],
  providers: [
    StatusBar, SplashScreen,
    { provide: ErrorHandler, useClass: IonicErrorHandler }
  ]
})
export class AppModule {
  // Make the injector to be available in the entire module
  // so we can use it in the custom decorator
  static injector: Injector;

  constructor(injector: Injector) {
    AppModule.injector = injector;
  }
}

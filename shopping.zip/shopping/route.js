var app = angular.module("myApp", ["ngRoute"]);
app.config(['$routeProvider','$locationProvider', function($routeProvider,$locationProvider) {
        $locationProvider.html5Mode ({enabled: true , requireBase: true , rewriteLinks: true });
    $routeProvider
    .when("/home", {
        templateUrl : "partials/home.html"
    })
    .when("/portfolio", {
        templateUrl : "partials/portfolio.html"
    })
    .when("/pricing-plan", {
        templateUrl : "partials/pricing-plan.html"
    })
	.when("/blog", {
        templateUrl : "partials/blog.html"
    })
	.when("/contact-us", {
        templateUrl : "partials/contact-us.html"
    })
	.otherwise({
		redirectTo: "/home"
	});
	
}]);app.config(['$locationProvider', function($location) {
    $location.hashPrefix('!');
}]);



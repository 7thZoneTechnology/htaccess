

app.service('httpService',function ($http) {

    this.getUserList=function () {
        var url='https://api.myjson.com/bins/1edijl';
        return $http.get(url).then(function(response) {
            return response.data;
        });
    }


    

});


app.controller('userListController',function ($scope,$state,httpService) {
    $scope.search = "";
    $scope.employees=[];
	$scope.clickedUser = {};
	$scope.message = ""; 
    httpService.getUserList().then(function (response) {
        $scope.employees.push(response);
        console.log(response);
    });

	 $scope.saveEmployee = function(){
		 $scope.employees.push($scope.createemp);
		 $scope.createemp = {};
          
		 $scope.message = "New User Added Successfully"; 
         
	 };
	 $scope.selectEmployee = function(emp){
		 $scope.clickedUser = emp; 
		
	 };
	  $scope.updateEmployee = function(){
        $scope.message = "User Updated Successfully"; 
     }
     $scope.clearMessage = function (){
      $scope.message = ""; 
	 }


	 
	 $scope.deleteEmployee = function(){
	  $scope.employees.splice($scope.employees.indexOf($scope.clickedUser),1); 
		$scope.message = "User Deleted Successfully"; 
	 }

     $scope.sort = {
        column: '',
        descending: false
    };    
    
    $scope.changeSorting = function(column) {

        var sort = $scope.sort;

        if (sort.column == column) {
            sort.descending = !sort.descending;
        } else {
            sort.column = column;
            sort.descending = false;
        }
    };
        
    $scope.selectedCls = function(column) {
        return column == $scope.sort.column && 'sort-' +$scope.sort.descending;
    };

});




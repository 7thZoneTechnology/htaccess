$(function() {
    "use strict";


$('#flat-widget-chart1').sparkline([5,8,7,10,9,10,8,6,4,6,8,7,6,8], {
            type: 'bar',
            height: '35',
            barWidth: '3',
            resize: true,
            barSpacing: '3',
            barColor: '#fff'
        });

     
     $("#flat-widget-chart2").sparkline([2,3,4,5,4,3,2,3,4,5,6,5,4,3,4,5], {
        type: 'discrete',
        width: '75',
        height: '40',
        lineColor: '#fff',
        lineHeight: 22

     });
    

    $("#flat-widget-chart3").sparkline([0,5,3,7,5,10,3,6,5,10], {
            type: 'line',
            width: '80',
            height: '40',
            lineWidth: '2',
            lineColor: '#fff',
            fillColor: 'transparent',
            spotColor: '#fff',
        })

		
		$("#flat-widget-chart4").sparkline([5,6,7,9,9,5,3,2,2,4,6,7], {
			type: 'line',
			width: '100',
			height: '25',
			lineWidth: '2',
			lineColor: '#ffffff',
			fillColor: 'transparent'
			
		});
	

	
	$('#flat-widget-chart5').sparkline([5,8,7,10,9,10,8,6,4,6,8,7,6,8], {
            type: 'bar',
            height: '35',
            barWidth: '3',
            resize: true,
            barSpacing: '3',
            barColor: '#fff'
        });

     
     $("#flat-widget-chart6").sparkline([2,3,4,5,4,3,2,3,4,5,6,5,4,3,4,5], {
        type: 'discrete',
        width: '75',
        height: '40',
        lineColor: '#fff',
        lineHeight: 22

     });
    

    $("#flat-widget-chart7").sparkline([0,5,3,7,5,10,3,6,5,10], {
            type: 'line',
            width: '80',
            height: '40',
            lineWidth: '2',
            lineColor: '#fff',
            fillColor: 'transparent',
            spotColor: '#fff',
        })

		
		$("#flat-widget-chart8").sparkline([5,6,7,9,9,5,3,2,2,4,6,7], {
			type: 'line',
			width: '100',
			height: '25',
			lineWidth: '2',
			lineColor: '#ffffff',
			fillColor: 'transparent'
			
		});
	
	
	$('#flat-widget-chart9').sparkline([5,8,7,10,9,10,8,6,4,6,8,7,6,8], {
            type: 'bar',
            height: '35',
            barWidth: '3',
            resize: true,
            barSpacing: '3',
            barColor: '#008cff'
        });

     
     $("#flat-widget-chart10").sparkline([2,3,4,5,4,3,2,3,4,5,6,5,4,3,4,5], {
        type: 'discrete',
        width: '75',
        height: '40',
        lineColor: '#fd3550',
        lineHeight: 22

     });
    

    $("#flat-widget-chart11").sparkline([0,5,3,7,5,10,3,6,5,10], {
            type: 'line',
            width: '80',
            height: '40',
            lineWidth: '2',
            lineColor: '#15ca20',
            fillColor: 'transparent',
            spotColor: '#15ca20',
        })

		
		$("#flat-widget-chart12").sparkline([5,6,7,9,9,5,3,2,2,4,6,7], {
			type: 'line',
			width: '100',
			height: '25',
			lineWidth: '2',
			lineColor: '#ff9700',
			fillColor: 'transparent'
			
		});
	

	
	$('#flat-widget-chart13').sparkline([5,8,7,10,9,10,8,6,4,6,8,7,6,8], {
            type: 'bar',
            height: '35',
            barWidth: '3',
            resize: true,
            barSpacing: '3',
            barColor: '#008cff'
        });

     
     $("#flat-widget-chart14").sparkline([2,3,4,5,4,3,2,3,4,5,6,5,4,3,4,5], {
        type: 'discrete',
        width: '75',
        height: '40',
        lineColor: '#fd3550',
        lineHeight: 22

     });
    

    $("#flat-widget-chart15").sparkline([0,5,3,7,5,10,3,6,5,10], {
            type: 'line',
            width: '80',
            height: '40',
            lineWidth: '2',
            lineColor: '#15ca20',
            fillColor: 'transparent',
            spotColor: '#15ca20',
        })

		
		$("#flat-widget-chart16").sparkline([5,6,7,9,9,5,3,2,2,4,6,7], {
			type: 'line',
			width: '100',
			height: '25',
			lineWidth: '2',
			lineColor: '#ff9700',
			fillColor: 'transparent'
			
		});
	
	
	
	
	
	
});	
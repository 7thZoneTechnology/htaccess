angular.module("myApp").controller('blogController', function ($location, $window, $q, $scope, $timeout, $http) {

    // $http.get("http://www.infoziant.com/json/json.php")
    //.then(function (response) {
    //    $scope.message = response.data;
    //});
   $http.get("https://www.w3schools.com/angular/customers.php").then(function (response) {
        $scope.myData = response.data.records;
    });

})

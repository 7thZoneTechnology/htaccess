angular.module("myApp").controller('indexController', function ($location, $window, $q, $scope, $timeout, $http) {

    $scope.menuclick = function (link) {
        $location.path(link);
    }


})

﻿"use strict";

angular.module("myApp").directive("mainView", function () {
    return {
        restrict: 'AE',
        replace: false,
        transclude: false,
        scope: {
           
        },
        //controller: "nmainviewController",
        //templateUrl: "ext-modules/navconFramework/navconFrameworkTemplate.html"
        templateUrl:"../directives/layout.html"

    };
});


var app = angular.module("myApp", ["ngRoute"]);

app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider, $rootScope, $timeout) {

    $routeProvider
    .when("/home", {
        templateUrl: "partials/home.html",
        controller: "homeController"
       
    })
    .when("/portfolio", {
        templateUrl: "partials/portfolio.html"
    })
    .when("/pricing-plan", {
        templateUrl: "partials/pricing-plan.html"
    })
	.when("/blog", {
	    templateUrl: "partials/blog.html"
	})
	.when("/contact-us", {
	    templateUrl: "partials/contact-us.html"
	})
	.otherwise({
	    redirectTo: "/home"
	});
    $locationProvider.html5Mode(true).hashPrefix('!');
}]);


app.run(['$rootScope', function ($root) {
    $root.$on('$routeChangeStart', function (e, curr, prev) {
        if (curr.$$route && curr.$$route.resolve) {
            // Show a loading message until promises aren't resolved
            $root.loadingView = true;
        }
    });
    $root.$on('$routeChangeSuccess', function (e, curr, prev) {
        // Hide loading message
        $root.loadingView = false;
    });
}]);
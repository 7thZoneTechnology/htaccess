

var app = angular.module("myApp", ["ngRoute"]);

app.config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {

    $routeProvider
    .when("/home", {
        templateUrl: "partials/home.html",
        controller: "homeController"
       
    })
    .when("/portfolio", {
        templateUrl: "partials/portfolio.html"
    })
    .when("/pricing-plan", {
        templateUrl: "partials/pricing-plan.html"
    })
	.when("/blog", {
	    templateUrl: "partials/blog.html",
	    controller: "blogController"
	})
	.when("/contact-us", {
	    templateUrl: "partials/contact-us.html"
	})
	.otherwise({
	    redirectTo: "/home"
	});
    $locationProvider.html5Mode(true);
    $locationProvider.hashPrefix('');
}]);



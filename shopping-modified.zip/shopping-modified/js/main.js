(function ($) {
    'use strict';


})(jQuery);



var app=angular.module('app',['ui.router','angularUtils.directives.dirPagination']);

app.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/list');

    $stateProvider
        .state('list', {
            url: '/list',
            templateUrl: 'user-list.html',
            controller:'userListController'
        });
  
});


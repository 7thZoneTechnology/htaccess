var bgAudio;

var feedAudio;

var isMp3Supported;

var delay_woodInterval = [70];
var isActivityOver = 0;

var wrongClicked = 0;

var correctClicked = 0;

var isDragVal = true;

var bombX;

var bombIY;



var bombHitInterval;

var guardInterval;

var blastInterval;

var imagesDownInterval_1;

var gameOverInterval;

var downReached = 0;

var fallSpeed = .2;

var newPointVal= 0;

var currentquesno= 1;
 
curHitNumber =0;



corAnsArr= [1,1,2,2,2];


function formatTimerFun(timerValSecs) {

    inMins = Math.floor(timerValSecs / 60);

    inSecs = timerValSecs % 60;

    inMins = (String(inMins).length == 1) ? ('0' + inMins) : inMins;

    inSecs = (String(inSecs).length == 1) ? ('0' + inSecs) : inSecs;

    $("#timerID").html(inMins + ":" + inSecs);

    //alert(inMins+":"+inSecs);

}

//////////////////////////////

function timerFunction() {

   

    timerInterval = setInterval(function() {

        timerValSecs--;

        formatTimerFun(timerValSecs);

        if (timerValSecs == 0) {

            timelapse = 1;

            stopActivity(); 
			
			clearInterval(timerInterval);

        }

    }, 1000)


}


///////////////////////////////////////////////////////////////////

function checkMp3Support(myAudio) {

    var isMp3Support = false;

    if (myAudio.canPlayType) {

        if ("" != myAudio.canPlayType('audio/mpeg')) {

            isMp3Support = true;
        }

    } else {

        alert("no audio support");
    }

    return isMp3Support;
}


function createAudioTag() {

    bgAudio = document.createElement('audio');

    bgAudio.setAttribute('id', 'bgaudio');

    isMp3Supported = checkMp3Support(bgAudio);

    if (isMp3Supported) {

        bgAudio.setAttribute('src', 'sfx/bgsound.mp3');

    } else {

        bgAudio.setAttribute('src', 'sfx/bgsound.ogg');

    }
    bgAudio.load();

    bgAudio.play();

    bgAudio.volume = 0.5;

    bgAudio.addEventListener("ended", bgLoadAgain, false);

    feedAudio = document.createElement('audio');

    feedAudio.setAttribute('id', 'feedaudio');

    feedAudio.addEventListener("ended", bgLoadAgain, false);

}

function bgLoadAgain(e) {

    bgAudio.play();

}

function feedStartAudio(voName) {

    feedAudio.pause();

    bgAudio.pause();

    if (isMp3Supported) {

        feedAudio.setAttribute('src', 'sfx/' + voName + '.mp3');

    } else {

        feedAudio.setAttribute('src', 'sfx/' + voName + '.ogg');

    }

    feedAudio.load();

    feedAudio.play();

    isFeddEnd = 0;

}

function isaudioMute(valU) {

    bgAudio.volume = valU > 0 ? 0.01 : valU;

    wordAudio.volume = valU;

    feedAudio.volume = valU;

}


///////////////////////////////////////////////////

function setBombInterval() {

    bombHitInterval = setInterval(checkBombHit, 50);

}

var isbombHit1 = false;

var isbombHit2 = false;



function checkBombHit() {

    if (bombPressed == 0 || downReached == 1) {

        return null;

    }

    isbombHit1 = $("#bomb").objectHitTest({

        "object": $("#dropDiv1"),

        "transparency": true

    });

    isbombHit2 = $("#bomb").objectHitTest({

        "object": $("#dropDiv2"),

        "transparency": true

    });


    if (isbombHit1) {

        curHitNumber = 1;

    } else if (isbombHit2) {

        curHitNumber = 2;

    }


    if (curHitNumber != 0) {
		
		clearInterval(imagesDownInterval_1);
	
  
	

        bombPressed = 0;

        clearInterval(bombHitInterval);

        $("#bomb").clearQueue().stop().css("opacity", 0);

        currHitImage = $(eval('"#dropImage' + curHitNumber + '"'));

        currHitDiv = $(eval('"#dropDiv' + curHitNumber + '"'));
		
		
		

		
        animateDiv(currHitDiv, "woodInterval", 200, 6,0);
		
		
		
		
		
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
        if (currHitImage.attr("curPic") == $(".rocket_continer_txt").attr("curPic")) {

		
            feedStartAudio("correct");
				
        } else {

            feedStartAudio("wrong");
        }
				
    }

  
}


var clearedImages = 0;

function changeImageFun() {

    if (downReached == 1) {

        return null;

    }

    blastInterval = setInterval(function() {

        if (wordsArray.length == 0 && clearedImages == 2) {

            showScoreBoard();

            clearInterval(blastInterval);

            return null;

        }
else{

}



        isDragVal = true;

        $("#bomb").css("opacity", 1);

        currHitDiv.css("top", 0);

        $("#bomb").css({
			
            'top': bombIY
        });

        setBombInterval();

        curHitNumber = 0;

        clearInterval(blastInterval);

    }, 800)
	

	
	
}








var imageDownInc1 = 0;

var imageDownInc2 = 0;

var alphaVal = 1;



function isBottomReachd() {

    if (imageDownInc1 > 300 || imageDownInc2 > 300) {

      	downReached = 1;

        clearInterval(isBottmReachdInterval);
		
		  clearInterval(bombHitInterval);
		
		
        feedAudio.pause();

        feedStartAudio("wrong");

       


        gameOverInterval = setInterval(function() {


            clearInterval(imagesDownInterval_1);
			
            clearInterval(imagesDownInterval_2);
			     	
            clearInterval(gameOverInterval);
			
            clearInterval(bombHitInterval);
			
            clearInterval(guardInterval);
			
            clearInterval(blastInterval);

            $("#mainSection").find(".top_img_continer").remove();

            $("#mainSection").find(".rocket_continer").remove();

        }, 1000);

    }
}

var isBottmReachdInterval = setInterval(isBottomReachd, 10);

function imagesFalling1() {
	

    if (curHitNumber != 1) {

        imageDownInc1 += fallSpeed;

    }

    $("#dropDiv1, #dropDiv2").css("top", imageDownInc1);

    if (downReached == 1) {

        alphaVal -= 0.02;

        $("#dropDiv1, #dropDiv2").css("opacity", alphaVal);
		
		

    }

    // isBottomReachd();

}



var bombPressed = 0;

function setDropXpos(){
	
	var xposArr = [100,550];
	
	ran1 =Number(String(xposArr.splice(Math.floor(Math.random()*xposArr.length),1)));
	
	ran2 =Number(String(xposArr.splice(Math.floor(Math.random()*xposArr.length),1)));
		
		
         ran1 = ran1+(Math.ceil(Math.random()*200));

         ran2 = ran2+(Math.ceil(Math.random()*200));


	   $("#dropDiv1").css("left",ran1+'px' );
	
	  $("#dropDiv2").css("left", ran2+'px');

	
	 $("#dropDiv1, #dropDiv2").css("top", '0px');
	   
	
	 
	//$('#bomber').css({'transform' : 'rotate('+ 50 +'deg)'});
}





function animateDiv(ele, delayFunc, delayWidth, picNum, repeat) {

	
    ele.attr('index', 0);
    createDelay(ele, delayFunc, delayWidth, picNum, repeat);

}




function createDelay(activDiv, delayFunc, delayWidth, picNum, repeat) {

    var delayIndex = Number(activDiv.attr('index'));
	
    var delayTime = eval("delay_" + delayFunc + "[" + 0 + "]");
	
	

    window.setTimeout(function() {	
 		 
        var isCalledAgain = Number(activDiv.attr('isCalledAgain'));
		
	    	if(isCalledAgain==1){
		  
		  	 activDiv.attr('isCalledAgain', ""); 
			 
		     var restartVal= (activDiv.attr('restructure')).split(",");		   
			
			activDiv.css("background-position", (-(restartVal[1] * 0) + "px 0px"));
					  
		    createDelay(activDiv, restartVal[0], restartVal[1], restartVal[2], Number(restartVal[3])); 
		   
		    return null;
		   
		  }
		 
		delayIndex += 1;
	
		
     if( delayIndex < picNum){
	 
	   activDiv.attr('index', delayIndex); 
	   
       activDiv.css("background-position", (-(delayWidth * delayIndex) + "px 0px"));
	   
	   createDelay(activDiv, delayFunc, delayWidth, picNum, repeat); 
	   
	   } 
	   
	  else if( delayIndex == picNum && repeat){
	 
	        activDiv.attr('index', -1); 
			
			createDelay(activDiv, delayFunc, delayWidth, picNum, repeat); 
			

	   } 
	   
	
	     	   	    
	 
    }, delayTime);
	
	



}





$(document).ready(function() {


 $("body").css("opacity", "1");  

 createAudioTag();
 
 
 setDropXpos();
 
     $("#bomber").css('left','400px')
	 
	 
	 
	 
	 

 
window.setTimeout(function(){


    mainSectionX = $("#mainSection").offset().left;

    bombIY = $("#bomb").css("top");

    $("#mainSection").on("mousemove", function(e) {

        if (downReached) {

            return null;

        }

        if (isDragVal) {

            // $("#tracer").text(xdiff);

            var xdiff = e.pageX - mainSectionX;

            if (xdiff > 100 && xdiff < 900) {
				
                bombX = e.pageX - mainSectionX - 84;
				
				var ang= (400-bombX)/10;
				
			//	$('#bomber').css({'transform' : 'rotate('+ -ang +'deg)'});

                $("#bomber").css({

                    'left': bombX

                });             

            }
        }

    });

	
	
	

    $("#mainSection").click(function() {

	    if (downReached) {

            return null;

        }
		
		

        if (isDragVal) {

            isDragVal = false;

            bombPressed = 1;

            $("#bomb").animate({

                top: "-500px",

                opacity: '-=0.7'

            }, 500, function() {

                if (curHitNumber != 0) {

                    //	return null;

                }

                $(this).css("opacity", 1);

                $(this).css({
                    'top': bombIY
                });

                isDragVal = true;
				
                bombPressed = 0;

            })

        }

    })


    imagesDownInterval_1 = setInterval(imagesFalling1, 1);


    setBombInterval();	
	
	timerValSecs = 120;
	
	 formatTimerFun(timerValSecs) 
		
	   timerFunction();
	
	},1000);
	
	
	
	


	
});



if(corAnsArr[currentquesno] == userclickedno ){

alert(11111);

		$("userclickedno", function(){
    $(this).find('img').attr('src', '../images/gameImages/opt_wro1.png');                         
});





     /* $("#dropImage1").click(function (){
          $('img').attr ({
          src: "../images/gameImages/opt_wro1.png"
        
         });
        });


*/




//corAnsArr[0].src=("../images/gameImages/opt_wro1.png");


 //$(this).find("#dropImage1").html('<img src="../images/gameImages/opt_wro1.png">');
 
 
$("#dropImage1" ).css("background", "url(../images/gameImages/opt_wro1.png");



}
